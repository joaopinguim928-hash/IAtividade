# IAtividade

**IAtividade** é uma plataforma educacional inteligente para criação de atividades interativas (quizzes de múltipla escolha, questões dissertativas com autocorreção, tabelas de conjugação verbal), mapas mentais e gráficos dinâmicos com suporte a Inteligência Artificial.

## 🚀 Como Executar Localmente

### Pré-requisitos
- Node.js 18.x ou superior
- npm, yarn ou pnpm

### Passos
1. Instale as dependências:
   ```bash
   npm install
   ```

2. Inicie o servidor de desenvolvimento:
   ```bash
   npm run dev
   ```

3. Acesse no navegador:
   `http://localhost:3000`

---

## 🌐 Implantação na Vercel

1. Importe este repositório no dashboard da Vercel.
2. Certifique-se de que as configurações de build são as padrão do Next.js:
   - **Framework Preset**: Next.js
   - **Build Command**: `next build`
   - **Output Directory**: `.next` (padrão)
3. Clique em **Deploy**.

---

## 🛠️ Tecnologias Utilizadas
- **Next.js 14** (App Router) & **React 18**
- **TypeScript**
- **Tailwind CSS**
- **Recharts** (Gráficos)
- **Lucide Icons**
