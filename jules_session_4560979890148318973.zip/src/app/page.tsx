'use client';

import React, { useState } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import { ActivityProvider, useActivities } from '@/context/ActivityContext';
import { Navbar } from '@/components/Navbar';
import { Sidebar } from '@/components/Sidebar';
import { DashboardView } from '@/components/DashboardView';
import { AuthModal } from '@/components/AuthModal';
import { AiPromptModal } from '@/components/AiPromptModal';
import { QuizEditor } from '@/components/QuizEditor';
import { QuizPlayer } from '@/components/QuizPlayer';
import { DissertativeEditor } from '@/components/DissertativeEditor';
import { DissertativePlayer } from '@/components/DissertativePlayer';
import { VerbTableEditor } from '@/components/VerbTableEditor';
import { VerbTablePlayer } from '@/components/VerbTablePlayer';
import { MindMapEditor } from '@/components/MindMapEditor';
import { MindMapPlayer } from '@/components/MindMapPlayer';
import { ChartEditor } from '@/components/ChartEditor';
import { ChartPlayer } from '@/components/ChartPlayer';
import {
  QuizActivity,
  DissertativeActivity,
  VerbTableActivity,
  MindMapActivity,
  ChartActivity,
} from '@/types';

function MainWorkspace() {
  const { activeView, selectedActivity } = useActivities();
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  const renderMainContent = () => {
    switch (activeView) {
      case 'create_quiz':
        return <QuizEditor />;
      case 'create_dissertative':
        return <DissertativeEditor />;
      case 'create_verb':
        return <VerbTableEditor />;
      case 'create_mindmap':
        return <MindMapEditor />;
      case 'create_chart':
        return <ChartEditor />;
      case 'play_activity':
        if (!selectedActivity) return <DashboardView onOpenAiModal={() => setIsAiModalOpen(true)} />;
        switch (selectedActivity.type) {
          case 'quiz':
            return <QuizPlayer activity={selectedActivity as QuizActivity} />;
          case 'dissertative':
            return <DissertativePlayer activity={selectedActivity as DissertativeActivity} />;
          case 'verb_table':
            return <VerbTablePlayer activity={selectedActivity as VerbTableActivity} />;
          case 'mindmap':
            return <MindMapPlayer activity={selectedActivity as MindMapActivity} />;
          case 'chart':
            return <ChartPlayer activity={selectedActivity as ChartActivity} />;
          default:
            return <DashboardView onOpenAiModal={() => setIsAiModalOpen(true)} />;
        }
      case 'dashboard':
      default:
        return <DashboardView onOpenAiModal={() => setIsAiModalOpen(true)} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/70 font-sans text-slate-800 flex flex-col">
      <Navbar onOpenAiModal={() => setIsAiModalOpen(true)} />

      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col lg:flex-row">
        <Sidebar onOpenAiModal={() => setIsAiModalOpen(true)} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {renderMainContent()}
        </main>
      </div>

      <AuthModal />
      <AiPromptModal isOpen={isAiModalOpen} onClose={() => setIsAiModalOpen(false)} />
    </div>
  );
}

export default function Home() {
  return (
    <AuthProvider>
      <ActivityProvider>
        <MainWorkspace />
      </ActivityProvider>
    </AuthProvider>
  );
}
