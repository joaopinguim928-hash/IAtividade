import { AnyActivity, QuizActivity, DissertativeActivity, VerbTableActivity, MindMapActivity, ChartActivity } from '@/types';

export async function generateContentWithAI(
  prompt: string,
  targetType: 'auto' | 'quiz' | 'dissertative' | 'verb_table' | 'mindmap' | 'chart'
): Promise<AnyActivity> {
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const lowerPrompt = prompt.toLowerCase();
  const timestamp = Date.now();

  let selectedType = targetType;
  if (selectedType === 'auto') {
    if (lowerPrompt.includes('verbo') || lowerPrompt.includes('conjug') || lowerPrompt.includes('pretérito') || lowerPrompt.includes('futuro')) {
      selectedType = 'verb_table';
    } else if (lowerPrompt.includes('mapa') || lowerPrompt.includes('mental') || lowerPrompt.includes('esquema') || lowerPrompt.includes('diagrama')) {
      selectedType = 'mindmap';
    } else if (lowerPrompt.includes('gráfico') || lowerPrompt.includes('grafico') || lowerPrompt.includes('dados') || lowerPrompt.includes('porcentagem') || lowerPrompt.includes('estatística')) {
      selectedType = 'chart';
    } else if (lowerPrompt.includes('dissertativ') || lowerPrompt.includes('redação') || lowerPrompt.includes('resposta aberta') || lowerPrompt.includes('discorra')) {
      selectedType = 'dissertative';
    } else {
      selectedType = 'quiz';
    }
  }

  if (selectedType === 'verb_table') {
    let verb = 'estudar';
    if (lowerPrompt.includes('cantar')) verb = 'cantar';
    else if (lowerPrompt.includes('vender')) verb = 'vender';
    else if (lowerPrompt.includes('partir')) verb = 'partir';
    else if (lowerPrompt.includes('fazer')) verb = 'fazer';
    else if (lowerPrompt.includes('ir')) verb = 'ir';
    else if (lowerPrompt.includes('ter')) verb = 'ter';
    else {
      const match = lowerPrompt.match(/verbo\s+([a-zA-Zà-úÀ-Ú]+)/i);
      if (match && match[1]) verb = match[1].trim();
    }

    let tense = 'Presente do Indicativo';
    if (lowerPrompt.includes('pretérito perfeito') || lowerPrompt.includes('passado')) {
      tense = 'Pretérito Perfeito do Indicativo';
    } else if (lowerPrompt.includes('pretérito imperfeito')) {
      tense = 'Pretérito Imperfeito do Indicativo';
    } else if (lowerPrompt.includes('futuro')) {
      tense = 'Futuro do Presente do Indicativo';
    }

    const verbActivity: VerbTableActivity = {
      id: `act_ai_verb_${timestamp}`,
      type: 'verb_table',
      title: `Conjugação Verbal: ${verb.toUpperCase()} (${tense})`,
      description: `Tabela gerada por IA para praticar a conjugação do verbo "${verb}" no ${tense}.`,
      verb: verb,
      tense: tense,
      subject: 'Língua Portuguesa',
      createdAt: new Date().toISOString(),
      authorId: 'usr_demo',
      conjugations: [
        { pronoun: 'Eu', answer: getVerbConjugation(verb, tense, 0) },
        { pronoun: 'Tu', answer: getVerbConjugation(verb, tense, 1) },
        { pronoun: 'Ele/Ela', answer: getVerbConjugation(verb, tense, 2) },
        { pronoun: 'Nós', answer: getVerbConjugation(verb, tense, 3) },
        { pronoun: 'Vós', answer: getVerbConjugation(verb, tense, 4) },
        { pronoun: 'Eles/Elas', answer: getVerbConjugation(verb, tense, 5) },
      ],
    };
    return verbActivity;
  }

  if (selectedType === 'mindmap') {
    const topic = extractTopic(prompt) || 'Tema de Estudo';
    const mindMapActivity: MindMapActivity = {
      id: `act_ai_mindmap_${timestamp}`,
      type: 'mindmap',
      title: `Mapa Mental: ${topic}`,
      description: `Mapa mental conceitual estruturado com IA sobre ${topic}.`,
      subject: 'Estudos Gerais',
      createdAt: new Date().toISOString(),
      authorId: 'usr_demo',
      root: {
        id: 'n_root',
        label: topic,
        description: `Conceito Central de ${topic}`,
        color: '#4f46e5',
        children: [
          {
            id: 'n_sub1',
            label: 'Conceitos Fundamentais',
            description: 'Definição e princípios primários',
            color: '#0284c7',
            children: [
              { id: 'n_sub1_1', label: 'Origem & História', description: 'Contexto e evolução' },
              { id: 'n_sub1_2', label: 'Pilares Principais', description: 'Bases sustentadoras' },
            ],
          },
          {
            id: 'n_sub2',
            label: 'Aplicações Práticas',
            description: 'Exemplos no mundo real',
            color: '#059669',
            children: [
              { id: 'n_sub2_1', label: 'Casos de Uso', description: 'Exemplos cotidianos' },
              { id: 'n_sub2_2', label: 'Impacto Social', description: 'Consequências diretas' },
            ],
          },
          {
            id: 'n_sub3',
            label: 'Perspectivas Futuras',
            description: 'Tendências e inovações',
            color: '#9333ea',
            children: [
              { id: 'n_sub3_1', label: 'Desafios', description: 'Obstáculos a superar' },
              { id: 'n_sub3_2', label: 'Oportunidades', description: 'Novos caminhos' },
            ],
          },
        ],
      },
    };
    return mindMapActivity;
  }

  if (selectedType === 'chart') {
    const topic = extractTopic(prompt) || 'Comparativo de Dados';
    const chartActivity: ChartActivity = {
      id: `act_ai_chart_${timestamp}`,
      type: 'chart',
      chartType: lowerPrompt.includes('pizza') ? 'pie' : lowerPrompt.includes('linha') ? 'line' : 'bar',
      title: `Gráfico: ${topic}`,
      description: `Análise estatística e visualização gráfica de dados sobre ${topic}.`,
      subject: 'Análise de Dados',
      createdAt: new Date().toISOString(),
      authorId: 'usr_demo',
      dataKeys: ['valor'],
      data: [
        { name: 'Categoria A', valor: 45 },
        { name: 'Categoria B', valor: 75 },
        { name: 'Categoria C', valor: 30 },
        { name: 'Categoria D', valor: 90 },
        { name: 'Categoria E', valor: 60 },
      ],
    };
    return chartActivity;
  }

  if (selectedType === 'dissertative') {
    const topic = extractTopic(prompt) || 'Tema Proposto';
    const dissActivity: DissertativeActivity = {
      id: `act_ai_diss_${timestamp}`,
      type: 'dissertative',
      title: `Questão Dissertativa: ${topic}`,
      description: `Atividade de resposta aberta sobre ${topic} com critérios de correção automática.`,
      subject: 'Conhecimentos Gerais',
      createdAt: new Date().toISOString(),
      authorId: 'usr_demo',
      questions: [
        {
          id: 'dq_ai_1',
          prompt: `Apresente uma reflexão crítica sobre a importância de ${topic} no contexto atual, destacando pelo menos dois fatores determinantes e suas possíveis consequências.`,
          rubric: `O estudante deve demonstrar compreensão clara de ${topic}, utilizar vocabulário adequado, citar no mínimo dois fatores e articular causa e efeito de maneira coerente.`,
          sampleAnswer: `A análise sobre ${topic} revela que sua compreensão é fundamental no cenário contemporâneo. Fatores como desenvolvimento contínuo e impacto estrutural geram transformações significativas na sociedade.`,
          maxPoints: 10,
        },
      ],
    };
    return dissActivity;
  }

  const topic = extractTopic(prompt) || 'Tópico de Conhecimento';
  const quizActivity: QuizActivity = {
    id: `act_ai_quiz_${timestamp}`,
    type: 'quiz',
    title: `Quiz Interativo: ${topic}`,
    description: `Conjunto de questões de múltipla escolha geradas por IA para testar conceitos de ${topic}.`,
    subject: 'Geral',
    createdAt: new Date().toISOString(),
    authorId: 'usr_demo',
    questions: [
      {
        id: 'q_ai_1',
        question: `Qual é o pilar fundamental associado ao tema de ${topic}?`,
        options: [
          `A estruturação conceitual e aplicação prática de ${topic}`,
          'A negação de evidências empíricas',
          'Apenas aspectos secundários irrelevantes',
          'Nenhuma das alternativas anteriores',
        ],
        correctAnswer: 0,
        explanation: `${topic} fundamenta-se na integração coerente entre teoria e prática.`,
      },
      {
        id: 'q_ai_2',
        question: `Em relação às principais características de ${topic}, assinale a alternativa correta:`,
        options: [
          'Ocorre isoladamente sem relação com o ambiente',
          `Desempenha papel ativo na transformação de seu campo de atuação`,
          'Não possui relevância acadêmica ou social',
          'Aplica-se somente a situações teóricas restritas',
        ],
        correctAnswer: 1,
        explanation: `${topic} impacta de forma direta a evolução da área de conhecimento.`,
      },
      {
        id: 'q_ai_3',
        question: `Qual das opções a seguir representa o objetivo central no estudo de ${topic}?`,
        options: [
          'Promover reflexão analítica e resolução de problemas',
          'Complicar processos simples desnecessariamente',
          'Substituir o pensamento crítico por dados genéricos',
          'Evitar o aprendizado contínuo',
        ],
        correctAnswer: 0,
        explanation: 'O foco pedagógico sempre visa desenvolver o pensamento crítico do estudante.',
      },
    ],
  };

  return quizActivity;
}

function extractTopic(prompt: string): string {
  const clean = prompt
    .replace(/crie/gi, '')
    .replace(/gerar/gi, '')
    .replace(/faça/gi, '')
    .replace(/um quiz/gi, '')
    .replace(/uma questão/gi, '')
    .replace(/um mapa mental/gi, '')
    .replace(/um gráfico/gi, '')
    .replace(/sobre/gi, '')
    .replace(/de/gi, '')
    .trim();

  if (!clean) return 'Conhecimentos Gerais';
  return clean.charAt(0).toUpperCase() + clean.slice(1);
}

function getVerbConjugation(verb: string, tense: string, personIndex: number): string {
  const stem = verb.endsWith('ar') || verb.endsWith('er') || verb.endsWith('ir') ? verb.slice(0, -2) : verb;
  const isAr = verb.endsWith('ar');
  const isEr = verb.endsWith('er');

  if (tense.includes('Presente')) {
    if (isAr) return ['canto', 'cantas', 'canta', 'cantamos', 'cantais', 'cantam'][personIndex].replace('cant', stem);
    if (isEr) return ['vendo', 'vendes', 'vende', 'vendemos', 'vendeis', 'vendem'][personIndex].replace('vend', stem);
    return ['parto', 'partes', 'parte', 'partimos', 'partis', 'partem'][personIndex].replace('part', stem);
  }

  if (tense.includes('Pretérito Perfeito')) {
    if (isAr) return ['cantei', 'cantaste', 'cantou', 'cantamos', 'cantastes', 'cantaram'][personIndex].replace('cant', stem);
    if (isEr) return ['vendi', 'vendeste', 'vendeu', 'vendemos', 'vendestes', 'venderam'][personIndex].replace('vend', stem);
    return ['parti', 'partiste', 'partiu', 'partimos', 'partistes', 'partiram'][personIndex].replace('part', stem);
  }

  if (isAr) return ['cantarei', 'cantarás', 'cantará', 'cantaremos', 'cantareis', 'cantarão'][personIndex].replace('cant', stem);
  return ['venderei', 'venderás', 'venderá', 'venderemos', 'vendereis', 'venderão'][personIndex].replace('vend', stem);
}
