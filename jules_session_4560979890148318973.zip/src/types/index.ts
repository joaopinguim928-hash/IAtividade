export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'teacher' | 'student';
}

export type ActivityType = 'quiz' | 'dissertative' | 'verb_table' | 'mindmap' | 'chart';

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}

export interface QuizActivity {
  id: string;
  type: 'quiz';
  title: string;
  description: string;
  subject: string;
  createdAt: string;
  questions: QuizQuestion[];
  authorId: string;
}

export interface DissertativeQuestion {
  id: string;
  prompt: string;
  rubric: string;
  sampleAnswer?: string;
  maxPoints?: number;
}

export interface DissertativeActivity {
  id: string;
  type: 'dissertative';
  title: string;
  description: string;
  subject: string;
  createdAt: string;
  questions: DissertativeQuestion[];
  authorId: string;
}

export interface VerbConjugationRow {
  pronoun: string;
  answer: string;
}

export interface VerbTableActivity {
  id: string;
  type: 'verb_table';
  title: string;
  description: string;
  verb: string;
  tense: string;
  subject: string;
  createdAt: string;
  conjugations: VerbConjugationRow[];
  authorId: string;
}

export interface MindMapNode {
  id: string;
  label: string;
  description?: string;
  color?: string;
  children?: MindMapNode[];
}

export interface MindMapActivity {
  id: string;
  type: 'mindmap';
  title: string;
  description: string;
  subject: string;
  createdAt: string;
  root: MindMapNode;
  authorId: string;
}

export interface ChartDataItem {
  name: string;
  value?: number;
  [key: string]: string | number | undefined;
}

export interface ChartActivity {
  id: string;
  type: 'chart';
  chartType: 'bar' | 'line' | 'pie' | 'radar';
  title: string;
  description: string;
  subject: string;
  createdAt: string;
  dataKeys: string[];
  data: ChartDataItem[];
  authorId: string;
}

export type AnyActivity =
  | QuizActivity
  | DissertativeActivity
  | VerbTableActivity
  | MindMapActivity
  | ChartActivity;
