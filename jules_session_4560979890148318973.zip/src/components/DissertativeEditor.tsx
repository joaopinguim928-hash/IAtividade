'use client';

import React, { useState } from 'react';
import { useActivities } from '@/context/ActivityContext';
import { DissertativeActivity, DissertativeQuestion } from '@/types';
import { ArrowLeft, Save, FileText, Plus, Trash2 } from 'lucide-react';

export function DissertativeEditor() {
  const { addActivity, setActiveView, setSelectedActivity } = useActivities();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('Redação e Análise');
  const [questions, setQuestions] = useState<DissertativeQuestion[]>([
    {
      id: 'dq_' + Date.now(),
      prompt: '',
      rubric: '',
      sampleAnswer: '',
      maxPoints: 10,
    },
  ]);

  const handleAddQuestion = () => {
    setQuestions([
      ...questions,
      {
        id: 'dq_' + Date.now(),
        prompt: '',
        rubric: '',
        sampleAnswer: '',
        maxPoints: 10,
      },
    ]);
  };

  const handleRemoveQuestion = (index: number) => {
    if (questions.length === 1) return;
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const handleQuestionChange = <K extends keyof DissertativeQuestion>(
    index: number,
    field: K,
    value: DissertativeQuestion[K]
  ) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], [field]: value };
    setQuestions(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || questions.some((q) => !q.prompt.trim())) return;

    const newActivity: DissertativeActivity = {
      id: 'act_diss_' + Date.now(),
      type: 'dissertative',
      title,
      description,
      subject,
      createdAt: new Date().toISOString(),
      questions,
      authorId: 'usr_demo',
    };

    addActivity(newActivity);
    setSelectedActivity(newActivity);
    setActiveView('play_activity');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 flex items-center gap-1.5">
          <FileText className="w-4 h-4 text-emerald-500" />
          <span>Nova Atividade Dissertativa</span>
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h2 className="text-lg font-bold text-slate-800">Informações Gerais</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Título da Atividade</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Análise Crítica: Urbanização e Desafios Ambientais"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Disciplina / Matéria</label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Ex: Geografia"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>

            <div className="md:col-span-3">
              <label className="block text-xs font-bold text-slate-700 mb-1">Descrição</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Instruções para o aluno ao responder a questão dissertativa..."
                rows={2}
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-800">Questões Dissertativas ({questions.length})</h3>
            <button
              type="button"
              onClick={handleAddQuestion}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Questão</span>
            </button>
          </div>

          {questions.map((q, qIdx) => (
            <div
              key={q.id}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg">
                  Questão Dissertativa {qIdx + 1}
                </span>

                {questions.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveQuestion(qIdx)}
                    className="text-slate-400 hover:text-red-600 p-1 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Enunciado / Proposta de Redação
                </label>
                <textarea
                  required
                  rows={3}
                  value={q.prompt}
                  onChange={(e) => handleQuestionChange(qIdx, 'prompt', e.target.value)}
                  placeholder="Escreva a pergunta ou tema dissertativo que o aluno responderá..."
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Critérios de Correção da IA (Rubrica)
                </label>
                <input
                  type="text"
                  value={q.rubric}
                  onChange={(e) => handleQuestionChange(qIdx, 'rubric', e.target.value)}
                  placeholder="Ex: O aluno deve mencionar causa x, efeito y e usar argumento z..."
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Exemplo de Resposta Modelo (Gabarito Esperado)
                </label>
                <textarea
                  rows={2}
                  value={q.sampleAnswer || ''}
                  onChange={(e) => handleQuestionChange(qIdx, 'sampleAnswer', e.target.value)}
                  placeholder="Resposta ideal esperada como referência..."
                  className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none resize-none"
                />
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end pt-4">
          <button
            type="submit"
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Salvar Atividade Dissertativa</span>
          </button>
        </div>
      </form>
    </div>
  );
}
