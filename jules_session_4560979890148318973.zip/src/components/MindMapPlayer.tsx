'use client';

import React, { useState } from 'react';
import { MindMapActivity, MindMapNode } from '@/types';
import { useActivities } from '@/context/ActivityContext';
import {
  ArrowLeft,
  GitFork,
  ChevronDown,
  ChevronRight,
  ZoomIn,
  ZoomOut,
  RotateCcw,
} from 'lucide-react';

interface MindMapPlayerProps {
  activity: MindMapActivity;
}

export function MindMapPlayer({ activity }: MindMapPlayerProps) {
  const { setActiveView } = useActivities();

  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    [activity.root.id]: true,
  });
  const [zoomLevel, setZoomLevel] = useState<number>(1);

  const toggleExpand = (nodeId: string) => {
    setExpandedNodes((prev) => ({
      ...prev,
      [nodeId]: !prev[nodeId],
    }));
  };

  const renderNodeTree = (node: MindMapNode, isRoot: boolean = false) => {
    const hasChildren = node.children && node.children.length > 0;
    const isExpanded = expandedNodes[node.id] !== false;

    return (
      <div key={node.id} className="flex flex-col items-center my-2 relative">
        <div
          onClick={() => hasChildren && toggleExpand(node.id)}
          className={`px-4 py-3 rounded-2xl shadow-md border text-center cursor-pointer transition-all hover:scale-105 select-none relative group ${
            isRoot
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-indigo-700 min-w-[180px]'
              : 'bg-white text-slate-800 border-slate-200 hover:border-purple-300 min-w-[150px]'
          }`}
          style={{
            borderColor: !isRoot && node.color ? node.color : undefined,
            borderLeftWidth: !isRoot && node.color ? '4px' : undefined,
          }}
        >
          <div className="flex items-center justify-center gap-1.5 font-bold text-xs sm:text-sm">
            {hasChildren && (
              <span className="text-slate-400 group-hover:text-purple-600">
                {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
              </span>
            )}
            <span>{node.label}</span>
          </div>

          {node.description && (
            <p
              className={`text-[10px] mt-1 font-normal line-clamp-2 ${
                isRoot ? 'text-indigo-100' : 'text-slate-500'
              }`}
            >
              {node.description}
            </p>
          )}
        </div>

        {hasChildren && isExpanded && (
          <div className="relative pt-6 flex flex-wrap justify-center gap-6 sm:gap-8 before:absolute before:top-0 before:left-1/2 before:-translate-x-1/2 before:w-[2px] before:h-6 before:bg-slate-300">
            {node.children!.map((child) => renderNodeTree(child, false))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-sm gap-1">
            <button
              onClick={() => setZoomLevel((z) => Math.max(0.6, z - 0.1))}
              className="p-1.5 hover:bg-slate-100 text-slate-600 rounded-lg"
              title="Reduzir Zoom"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-[10px] font-bold text-slate-500 w-10 text-center">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={() => setZoomLevel((z) => Math.min(1.5, z + 0.1))}
              className="p-1.5 hover:bg-slate-100 text-slate-600 rounded-lg"
              title="Aumentar Zoom"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={() => setZoomLevel(1)}
              className="p-1.5 hover:bg-slate-100 text-slate-600 rounded-lg border-l border-slate-200 ml-1"
              title="Resetar Zoom"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          <span className="text-xs font-extrabold text-purple-700 bg-purple-50 px-3 py-1 rounded-full border border-purple-200 flex items-center gap-1.5">
            <GitFork className="w-4 h-4 text-purple-500" />
            <span>{activity.subject}</span>
          </span>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8 space-y-6 overflow-hidden">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{activity.title}</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">{activity.description}</p>
        </div>

        <div className="bg-slate-50/80 border border-slate-200 rounded-2xl p-8 min-h-[400px] flex items-center justify-center overflow-x-auto relative shadow-inner">
          <div
            className="transition-transform duration-200 origin-top flex flex-col items-center"
            style={{ transform: `scale(${zoomLevel})` }}
          >
            {renderNodeTree(activity.root, true)}
          </div>
        </div>
      </div>
    </div>
  );
}
