'use client';

import React, { useState } from 'react';
import { useActivities } from '@/context/ActivityContext';
import { ChartActivity, ChartDataItem } from '@/types';
import { ArrowLeft, Save, BarChart2, Plus, Trash2 } from 'lucide-react';

export function ChartEditor() {
  const { addActivity, setActiveView, setSelectedActivity } = useActivities();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('Análise de Dados');
  const [chartType, setChartType] = useState<'bar' | 'line' | 'pie' | 'radar'>('bar');
  const [valueKey, setValueKey] = useState('valor');

  const [data, setData] = useState<ChartDataItem[]>([
    { name: 'Item 1', valor: 30 },
    { name: 'Item 2', valor: 65 },
    { name: 'Item 3', valor: 45 },
    { name: 'Item 4', valor: 80 },
  ]);

  const handleRowChange = (idx: number, field: 'name' | 'valor', val: string | number) => {
    const updated = [...data];
    updated[idx] = {
      ...updated[idx],
      [field]: field === 'valor' ? Number(val) || 0 : val,
    };
    setData(updated);
  };

  const handleAddRow = () => {
    setData([...data, { name: `Item ${data.length + 1}`, valor: 50 }]);
  };

  const handleRemoveRow = (idx: number) => {
    if (data.length <= 1) return;
    setData(data.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || data.some((d) => !d.name.trim())) return;

    const newActivity: ChartActivity = {
      id: 'act_chart_' + Date.now(),
      type: 'chart',
      chartType,
      title,
      description: description || `Visualização em gráfico do tipo ${chartType}.`,
      subject,
      createdAt: new Date().toISOString(),
      dataKeys: [valueKey],
      data,
      authorId: 'usr_demo',
    };

    addActivity(newActivity);
    setSelectedActivity(newActivity);
    setActiveView('play_activity');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <span className="text-xs font-bold text-rose-700 bg-rose-50 px-3 py-1 rounded-full border border-rose-200 flex items-center gap-1.5">
          <BarChart2 className="w-4 h-4 text-rose-500" />
          <span>Novo Gráfico Interativo</span>
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h2 className="text-lg font-bold text-slate-800">Parâmetros do Gráfico</h2>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">Formato do Gráfico</label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { id: 'bar', label: '📊 Barras' },
                { id: 'line', label: '📈 Linha' },
                { id: 'pie', label: '🍕 Pizza' },
                { id: 'radar', label: '🕸️ Radar' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setChartType(t.id as 'bar' | 'line' | 'pie' | 'radar')}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition-all ${
                    chartType === t.id
                      ? 'bg-rose-50 border-rose-500 text-rose-700 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Título do Gráfico</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Evolução da Produção Industrial 2024"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Matéria / Categoria</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Ex: Geografia"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Descrição</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Resumo explicativo dos dados..."
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Nome da Métrica / Eixo Y</label>
              <input
                type="text"
                value={valueKey}
                onChange={(e) => setValueKey(e.target.value || 'valor')}
                placeholder="Ex: valor, % ou toneladas"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-rose-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-800">Conjunto de Dados (Data Points)</h3>
            <button
              type="button"
              onClick={handleAddRow}
              className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Adicionar Ponto
            </button>
          </div>

          <div className="space-y-2.5">
            {data.map((item, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <input
                  type="text"
                  required
                  value={item.name}
                  onChange={(e) => handleRowChange(idx, 'name', e.target.value)}
                  placeholder="Nome do Rótulo/Categoria"
                  className="flex-1 px-3.5 py-2 border border-slate-300 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />

                <input
                  type="number"
                  required
                  value={item[valueKey] !== undefined ? (item[valueKey] as number) : (item.valor as number) || 0}
                  onChange={(e) => handleRowChange(idx, 'valor', e.target.value)}
                  placeholder="Valor numérico"
                  className="w-28 sm:w-36 px-3.5 py-2 border border-slate-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />

                {data.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveRow(idx)}
                    className="p-2 text-slate-400 hover:text-red-600 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Salvar e Renderizar Gráfico</span>
          </button>
        </div>
      </form>
    </div>
  );
}
