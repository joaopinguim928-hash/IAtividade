'use client';

import React, { useState } from 'react';
import { useActivities } from '@/context/ActivityContext';
import { generateContentWithAI } from '@/services/aiService';
import {
  X,
  Sparkles,
  HelpCircle,
  FileText,
  Table,
  GitFork,
  BarChart2,
  Zap,
  Loader2,
} from 'lucide-react';

interface AiPromptModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type SelectedType = 'auto' | 'quiz' | 'dissertative' | 'verb_table' | 'mindmap' | 'chart';

export function AiPromptModal({ isOpen, onClose }: AiPromptModalProps) {
  const { addActivity, setSelectedActivity, setActiveView } = useActivities();

  const [prompt, setPrompt] = useState('');
  const [selectedType, setSelectedType] = useState<SelectedType>('auto');
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isGenerating) return;

    setIsGenerating(true);
    try {
      const generatedActivity = await generateContentWithAI(prompt, selectedType);
      addActivity(generatedActivity);
      setSelectedActivity(generatedActivity);
      setActiveView('play_activity');
      onClose();
      setPrompt('');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const samplePrompts: { type: SelectedType; text: string }[] = [
    { type: 'quiz', text: 'Crie um quiz com 3 perguntas sobre a Revolução Industrial e suas consequências.' },
    { type: 'verb_table', text: 'Tabela do verbo cantar no pretérito perfeito do indicativo.' },
    { type: 'mindmap', text: 'Mapa mental sobre o Ciclo das Rochas e tipos de solo.' },
    { type: 'chart', text: 'Gráfico comparativo de produção de energia eólica e solar.' },
    { type: 'dissertative', text: 'Questão dissertativa sobre ética na inteligência artificial com gabarito.' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100">
        <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-6 text-white relative">
          <button
            onClick={onClose}
            disabled={isGenerating}
            className="absolute top-4 right-4 text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-2 mb-2">
            <div className="p-2 bg-white/20 rounded-xl backdrop-blur-md">
              <Sparkles className="w-6 h-6 text-amber-300 animate-spin-slow" />
            </div>
            <span className="font-extrabold text-xl tracking-tight">Criar Recurso com IA</span>
          </div>
          <p className="text-xs text-indigo-100">
            Digite um tema, instrução ou selecione um tipo para a IA gerar automaticamente sua atividade.
          </p>
        </div>

        <form onSubmit={handleGenerate} className="p-6 space-y-5">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              1. Selecione o Formato
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedType('auto')}
                className={`p-2.5 rounded-xl border text-left transition-all text-xs font-semibold flex items-center gap-2 ${
                  selectedType === 'auto'
                    ? 'border-indigo-600 bg-indigo-50/80 text-indigo-700 shadow-sm'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-500 shrink-0" />
                <span className="truncate">Automático</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedType('quiz')}
                className={`p-2.5 rounded-xl border text-left transition-all text-xs font-semibold flex items-center gap-2 ${
                  selectedType === 'quiz'
                    ? 'border-amber-500 bg-amber-50 text-amber-800 shadow-sm'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <HelpCircle className="w-4 h-4 text-amber-500 shrink-0" />
                <span className="truncate">Quiz Múltipla</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedType('dissertative')}
                className={`p-2.5 rounded-xl border text-left transition-all text-xs font-semibold flex items-center gap-2 ${
                  selectedType === 'dissertative'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-800 shadow-sm'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <FileText className="w-4 h-4 text-emerald-500 shrink-0" />
                <span className="truncate">Dissertativa</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedType('verb_table')}
                className={`p-2.5 rounded-xl border text-left transition-all text-xs font-semibold flex items-center gap-2 ${
                  selectedType === 'verb_table'
                    ? 'border-sky-500 bg-sky-50 text-sky-800 shadow-sm'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <Table className="w-4 h-4 text-sky-500 shrink-0" />
                <span className="truncate">Tabela Verbos</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedType('mindmap')}
                className={`p-2.5 rounded-xl border text-left transition-all text-xs font-semibold flex items-center gap-2 ${
                  selectedType === 'mindmap'
                    ? 'border-purple-500 bg-purple-50 text-purple-800 shadow-sm'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <GitFork className="w-4 h-4 text-purple-500 shrink-0" />
                <span className="truncate">Mapa Mental</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedType('chart')}
                className={`p-2.5 rounded-xl border text-left transition-all text-xs font-semibold flex items-center gap-2 ${
                  selectedType === 'chart'
                    ? 'border-rose-500 bg-rose-50 text-rose-800 shadow-sm'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <BarChart2 className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="truncate">Gráfico</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              2. Descreva o que deseja criar
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Exemplo: Crie 3 perguntas sobre o Sistema Solar e planetas rochosos..."
              rows={3}
              required
              className="w-full p-3.5 border border-slate-300 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 resize-none"
            />
          </div>

          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              Sugestões Rápidas de Prompt
            </p>
            <div className="space-y-1.5 max-h-32 overflow-y-auto pr-1">
              {samplePrompts.map((s, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setPrompt(s.text);
                    setSelectedType(s.type);
                  }}
                  className="w-full text-left text-xs p-2 rounded-xl bg-slate-50 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 border border-slate-200/80 transition-colors truncate"
                >
                  💡 {s.text}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={isGenerating || !prompt.trim()}
            className="w-full py-3.5 px-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:to-pink-700 text-white rounded-2xl font-bold text-sm shadow-lg shadow-indigo-100 flex items-center justify-center gap-2 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin text-white" />
                <span>Gerando Recurso com Inteligência Artificial...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 text-amber-300" />
                <span>Gerar Recurso Agora</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
