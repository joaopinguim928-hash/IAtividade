'use client';

import React, { useState } from 'react';
import { QuizActivity } from '@/types';
import { useActivities } from '@/context/ActivityContext';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Sparkles,
  HelpCircle,
  ArrowRight,
  Award,
} from 'lucide-react';

interface QuizPlayerProps {
  activity: QuizActivity;
}

export function QuizPlayer({ activity }: QuizPlayerProps) {
  const { setActiveView } = useActivities();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [isFinished, setIsFinished] = useState(false);

  const currentQuestion = activity.questions[currentIndex];
  const totalQuestions = activity.questions.length;
  const selectedOption = selectedAnswers[currentIndex];
  const hasAnsweredCurrent = selectedOption !== undefined;

  const handleSelectOption = (optionIndex: number) => {
    if (hasAnsweredCurrent) return;

    const updated = { ...selectedAnswers, [currentIndex]: optionIndex };
    setSelectedAnswers(updated);

    if (optionIndex === currentQuestion.correctAnswer) {
      confetti({ particleCount: 30, spread: 60, origin: { y: 0.8 } });
    }
  };

  const handleNext = () => {
    if (currentIndex < totalQuestions - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      setIsFinished(true);
      confetti({ particleCount: 100, spread: 100, origin: { y: 0.6 } });
    }
  };

  const handleReset = () => {
    setCurrentIndex(0);
    setSelectedAnswers({});
    setIsFinished(false);
  };

  const correctCount = Object.entries(selectedAnswers).filter(
    ([qIdx, ansIdx]) => activity.questions[Number(qIdx)].correctAnswer === ansIdx
  ).length;

  const percentage = Math.round((correctCount / totalQuestions) * 100);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <span className="text-xs font-extrabold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200 flex items-center gap-1.5">
          <HelpCircle className="w-4 h-4 text-amber-500" />
          <span>{activity.subject}</span>
        </span>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{activity.title}</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">{activity.description}</p>
        </div>

        {!isFinished ? (
          <>
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-bold text-slate-500">
                <span>
                  Questão {currentIndex + 1} de {totalQuestions}
                </span>
                <span>{Math.round(((currentIndex + 1) / totalQuestions) * 100)}% concluído</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-amber-500 to-indigo-600 h-2.5 transition-all duration-300 rounded-full"
                  style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
                />
              </div>
            </div>

            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/80">
              <h2 className="text-base sm:text-lg font-bold text-slate-800 leading-snug">
                {currentQuestion.question}
              </h2>
            </div>

            <div className="space-y-3">
              {currentQuestion.options.map((option, oIdx) => {
                const isSelected = selectedOption === oIdx;
                const isCorrect = currentQuestion.correctAnswer === oIdx;

                let btnStyle =
                  'border-slate-200 bg-white hover:border-indigo-400 hover:bg-slate-50 text-slate-700';

                if (hasAnsweredCurrent) {
                  if (isCorrect) {
                    btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-semibold shadow-sm';
                  } else if (isSelected && !isCorrect) {
                    btnStyle = 'border-red-500 bg-red-50 text-red-900 font-semibold';
                  } else {
                    btnStyle = 'border-slate-200 opacity-50 bg-slate-50 text-slate-400';
                  }
                }

                return (
                  <button
                    key={oIdx}
                    disabled={hasAnsweredCurrent}
                    onClick={() => handleSelectOption(oIdx)}
                    className={`w-full p-4 rounded-2xl border text-left text-xs sm:text-sm transition-all flex items-center justify-between gap-3 ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-7 h-7 rounded-xl bg-slate-100 text-slate-600 font-bold flex items-center justify-center text-xs shrink-0">
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span>{option}</span>
                    </div>

                    {hasAnsweredCurrent && (
                      <div className="shrink-0">
                        {isCorrect && <CheckCircle2 className="w-5 h-5 text-emerald-600" />}
                        {isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-600" />}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {hasAnsweredCurrent && currentQuestion.explanation && (
              <div className="p-4 bg-indigo-50/80 rounded-2xl border border-indigo-100 text-xs text-indigo-900 space-y-1 animate-in fade-in duration-200">
                <p className="font-bold flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-600" /> Explicativo da Questão:
                </p>
                <p>{currentQuestion.explanation}</p>
              </div>
            )}

            {hasAnsweredCurrent && (
              <div className="flex justify-end pt-2">
                <button
                  onClick={handleNext}
                  className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
                >
                  <span>{currentIndex < totalQuestions - 1 ? 'Próxima Questão' : 'Ver Resultado'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-8 space-y-6 animate-in zoom-in-95 duration-200">
            <div className="w-20 h-20 bg-gradient-to-tr from-amber-400 to-indigo-600 text-white rounded-3xl flex items-center justify-center mx-auto shadow-xl shadow-indigo-100">
              <Award className="w-10 h-10" />
            </div>

            <div>
              <h2 className="text-2xl font-extrabold text-slate-800">Quiz Concluído!</h2>
              <p className="text-xs text-slate-500 mt-1">Veja seu desempenho no teste abaixo:</p>
            </div>

            <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200/80 inline-block w-full max-w-md">
              <div className="text-4xl font-extrabold text-indigo-600 mb-1">{percentage}%</div>
              <p className="text-xs font-semibold text-slate-600">
                Você acertou {correctCount} de {totalQuestions} questões
              </p>

              <div className="mt-4 pt-4 border-t border-slate-200 flex justify-center gap-4 text-xs font-medium text-slate-500">
                <span className="text-emerald-600 font-semibold">✓ {correctCount} Corretas</span>
                <span className="text-red-500 font-semibold">
                  ✕ {totalQuestions - correctCount} Incorretas
                </span>
              </div>
            </div>

            <div className="flex justify-center gap-3">
              <button
                onClick={handleReset}
                className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Refazer Quiz</span>
              </button>

              <button
                onClick={() => setActiveView('dashboard')}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs transition-colors shadow-md"
              >
                Voltar ao Painel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
