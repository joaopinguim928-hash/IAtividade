'use client';

import React from 'react';
import { useActivities } from '@/context/ActivityContext';
import { AnyActivity, QuizActivity, VerbTableActivity } from '@/types';
import {
  HelpCircle,
  FileText,
  Table,
  GitFork,
  BarChart2,
  Play,
  Trash2,
  Calendar,
  Sparkles,
  ArrowRight,
  BookOpen,
} from 'lucide-react';

interface DashboardViewProps {
  onOpenAiModal: () => void;
}

export function DashboardView({ onOpenAiModal }: DashboardViewProps) {
  const { activities, deleteActivity, setSelectedActivity, setActiveView, searchQuery, selectedFilter } =
    useActivities();

  const filtered = activities.filter((act) => {
    const matchesSearch =
      act.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      act.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      act.subject.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFilter = selectedFilter === 'all' || act.type === selectedFilter;

    return matchesSearch && matchesFilter;
  });

  const getBadgeInfo = (type: AnyActivity['type']) => {
    switch (type) {
      case 'quiz':
        return { label: 'Quiz Múltipla Escolha', bg: 'bg-amber-100 text-amber-800 border-amber-200', icon: HelpCircle };
      case 'dissertative':
        return { label: 'Questão Dissertativa', bg: 'bg-emerald-100 text-emerald-800 border-emerald-200', icon: FileText };
      case 'verb_table':
        return { label: 'Tabela de Verbos', bg: 'bg-sky-100 text-sky-800 border-sky-200', icon: Table };
      case 'mindmap':
        return { label: 'Mapa Mental', bg: 'bg-purple-100 text-purple-800 border-purple-200', icon: GitFork };
      case 'chart':
        return { label: 'Gráfico Interativo', bg: 'bg-rose-100 text-rose-800 border-rose-200', icon: BarChart2 };
    }
  };

  const handleOpenActivity = (act: AnyActivity) => {
    setSelectedActivity(act);
    setActiveView('play_activity');
  };

  return (
    <div className="space-y-8">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-700 via-purple-700 to-pink-600 p-8 text-white shadow-xl">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold mb-4 text-amber-300 border border-white/10">
            <Sparkles className="w-4 h-4" />
            <span>Gerador Inteligente de Conteúdos Pedagógicos</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight">
            Crie Atividades, Gráficos e Mapas Mentais com IA
          </h1>
          <p className="mt-3 text-sm sm:text-base text-indigo-100 font-normal">
            Gere exercícios interativos com autocorreção, tabelas de conjugação de verbos, mapas visuais e gráficos dinâmicos para aulas e estudos em poucos segundos.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              onClick={onOpenAiModal}
              className="px-5 py-3 bg-white text-indigo-700 hover:bg-amber-300 hover:text-slate-900 rounded-xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>Criar Novo Recurso com IA</span>
            </button>
          </div>
        </div>
        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute right-40 -top-10 w-48 h-48 bg-purple-500/20 rounded-full blur-xl pointer-events-none" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <button
          onClick={onOpenAiModal}
          className="p-4 bg-white border border-slate-200/80 rounded-2xl hover:border-amber-400 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <HelpCircle className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Quizzes</p>
          <p className="text-[10px] text-slate-400">Múltipla escolha</p>
        </button>

        <button
          onClick={onOpenAiModal}
          className="p-4 bg-white border border-slate-200/80 rounded-2xl hover:border-emerald-400 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <FileText className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Dissertativas</p>
          <p className="text-[10px] text-slate-400">Com correção IA</p>
        </button>

        <button
          onClick={onOpenAiModal}
          className="p-4 bg-white border border-slate-200/80 rounded-2xl hover:border-sky-400 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-600 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <Table className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Verbos</p>
          <p className="text-[10px] text-slate-400">Tabelas interativas</p>
        </button>

        <button
          onClick={onOpenAiModal}
          className="p-4 bg-white border border-slate-200/80 rounded-2xl hover:border-purple-400 hover:shadow-md transition-all text-left group"
        >
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <GitFork className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Mapas Mentais</p>
          <p className="text-[10px] text-slate-400">Nós e ramificações</p>
        </button>

        <button
          onClick={onOpenAiModal}
          className="p-4 bg-white border border-slate-200/80 rounded-2xl hover:border-rose-400 hover:shadow-md transition-all text-left group col-span-2 sm:col-span-1"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
            <BarChart2 className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-slate-800">Gráficos</p>
          <p className="text-[10px] text-slate-400">Barras, linhas, pizza</p>
        </button>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              Sua Biblioteca de Recursos ({filtered.length})
            </h2>
            <p className="text-xs text-slate-500">
              Gerencie, visualize e interaja com suas atividades criadas.
            </p>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="bg-white border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center">
            <div className="w-16 h-16 bg-indigo-50 text-indigo-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-slate-800">Nenhum recurso encontrado</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-6">
              Tente alterar os filtros de busca ou crie uma nova atividade usando a nossa IA assistente.
            </p>
            <button
              onClick={onOpenAiModal}
              className="px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-semibold hover:bg-indigo-700 transition-colors inline-flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Gerar Recurso com IA</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((act) => {
              const badge = getBadgeInfo(act.type);
              const BadgeIcon = badge.icon;

              return (
                <div
                  key={act.id}
                  className="bg-white rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md transition-all flex flex-col overflow-hidden group hover:border-indigo-200"
                >
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-3 gap-2">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold border ${badge.bg}`}
                        >
                          <BadgeIcon className="w-3.5 h-3.5" />
                          <span>{badge.label}</span>
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(act.createdAt).toLocaleDateString('pt-BR')}
                        </span>
                      </div>

                      <h3 className="text-base font-bold text-slate-800 group-hover:text-indigo-600 transition-colors line-clamp-2">
                        {act.title}
                      </h3>
                      <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                        {act.description}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                      <span className="font-medium text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-md text-[11px]">
                        {act.subject}
                      </span>

                      {act.type === 'quiz' && (
                        <span>{(act as QuizActivity).questions.length} questões</span>
                      )}
                      {act.type === 'verb_table' && (
                        <span className="capitalize">Verbo: {(act as VerbTableActivity).verb}</span>
                      )}
                    </div>
                  </div>

                  <div className="bg-slate-50/80 px-5 py-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => deleteActivity(act.id)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Excluir Atividade"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleOpenActivity(act)}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 shadow-sm"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Abrir Interativo</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
