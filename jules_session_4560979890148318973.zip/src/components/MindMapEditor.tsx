'use client';

import React, { useState } from 'react';
import { useActivities } from '@/context/ActivityContext';
import { MindMapActivity, MindMapNode } from '@/types';
import { ArrowLeft, Save, GitFork, Plus, Trash2 } from 'lucide-react';

export function MindMapEditor() {
  const { addActivity, setActiveView, setSelectedActivity } = useActivities();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [subject, setSubject] = useState('Geral');

  const [rootNode, setRootNode] = useState<MindMapNode>({
    id: 'n_root',
    label: '',
    description: '',
    color: '#4f46e5',
    children: [
      { id: 'n_1', label: 'Tópico 1', description: 'Detalhes do Tópico 1', color: '#0284c7' },
      { id: 'n_2', label: 'Tópico 2', description: 'Detalhes do Tópico 2', color: '#059669' },
    ],
  });

  const handleChildChange = (idx: number, field: keyof MindMapNode, val: string) => {
    if (!rootNode.children) return;
    const updated = [...rootNode.children];
    updated[idx] = { ...updated[idx], [field]: val };
    setRootNode({ ...rootNode, children: updated });
  };

  const handleAddChild = () => {
    const children = rootNode.children || [];
    const colors = ['#0284c7', '#059669', '#9333ea', '#e11d48', '#d97706'];
    const nextColor = colors[children.length % colors.length];

    setRootNode({
      ...rootNode,
      children: [
        ...children,
        {
          id: 'n_' + Date.now(),
          label: `Novo Tópico ${children.length + 1}`,
          description: '',
          color: nextColor,
        },
      ],
    });
  };

  const handleRemoveChild = (idx: number) => {
    if (!rootNode.children || rootNode.children.length <= 1) return;
    const updated = rootNode.children.filter((_, i) => i !== idx);
    setRootNode({ ...rootNode, children: updated });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rootNode.label.trim()) return;

    const newActivity: MindMapActivity = {
      id: 'act_mindmap_' + Date.now(),
      type: 'mindmap',
      title: title || `Mapa Mental: ${rootNode.label}`,
      description: description || `Mapa conceitual sobre ${rootNode.label}.`,
      subject,
      createdAt: new Date().toISOString(),
      root: rootNode,
      authorId: 'usr_demo',
    };

    addActivity(newActivity);
    setSelectedActivity(newActivity);
    setActiveView('play_activity');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <span className="text-xs font-bold text-purple-700 bg-purple-50 px-3 py-1 rounded-full border border-purple-200 flex items-center gap-1.5">
          <GitFork className="w-4 h-4 text-purple-500" />
          <span>Novo Mapa Mental</span>
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h2 className="text-lg font-bold text-slate-800">Definições Gerais</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Título do Mapa</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Mapa Mental - Sistema Sol e Planetas"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Disciplina / Matéria</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Ex: Ciências"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Descrição</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Breve descrição do mapa mental..."
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-6">
          <div className="p-4 bg-indigo-50 border-2 border-indigo-200 rounded-2xl space-y-3">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded">
              Nó Central (Tema Principal)
            </span>
            <input
              type="text"
              required
              value={rootNode.label}
              onChange={(e) => setRootNode({ ...rootNode, label: e.target.value })}
              placeholder="Digite o tema central do mapa mental..."
              className="w-full px-3.5 py-2.5 border border-indigo-300 rounded-xl text-sm font-bold text-indigo-900 focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white"
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-800">Ramificações / Subtópicos</h3>
              <button
                type="button"
                onClick={handleAddChild}
                className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Adicionar Ramificação
              </button>
            </div>

            {rootNode.children?.map((child, idx) => (
              <div
                key={child.id}
                className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 relative"
              >
                <div className="flex items-center gap-2">
                  <div
                    className="w-4 h-4 rounded-full shrink-0"
                    style={{ backgroundColor: child.color || '#9333ea' }}
                  />
                  <input
                    type="text"
                    required
                    value={child.label}
                    onChange={(e) => handleChildChange(idx, 'label', e.target.value)}
                    placeholder="Título da Ramificação..."
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white"
                  />

                  {rootNode.children && rootNode.children.length > 1 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveChild(idx)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <input
                  type="text"
                  value={child.description || ''}
                  onChange={(e) => handleChildChange(idx, 'description', e.target.value)}
                  placeholder="Descrição ou detalhe desta ramificação (Opcional)..."
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-xl text-xs text-slate-600 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-2xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Salvar e Visualizar Mapa Mental</span>
          </button>
        </div>
      </form>
    </div>
  );
}
