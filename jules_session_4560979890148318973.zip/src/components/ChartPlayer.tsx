'use client';

import React, { useState } from 'react';
import { ChartActivity } from '@/types';
import { useActivities } from '@/context/ActivityContext';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { ArrowLeft, BarChart2, Table } from 'lucide-react';

interface ChartPlayerProps {
  activity: ChartActivity;
}

const COLORS = ['#4f46e5', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

export function ChartPlayer({ activity }: ChartPlayerProps) {
  const { setActiveView } = useActivities();
  const [selectedType, setSelectedType] = useState<'bar' | 'line' | 'pie' | 'radar'>(
    activity.chartType
  );

  const dataKey = activity.dataKeys[0] || 'valor' || 'percentual';

  const renderChart = () => {
    switch (selectedType) {
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={activity.data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" stroke="#64748b" textAnchor="end" height={60} />
              <YAxis stroke="#64748b" />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}
              />
              <Legend />
              <Line type="monotone" dataKey={dataKey} stroke="#4f46e5" strokeWidth={3} dot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        );

      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={350}>
            <PieChart>
              <Pie
                data={activity.data}
                dataKey={dataKey}
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={110}
                label={(entry) => `${entry.name}`}
              >
                {activity.data.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );

      case 'radar':
        return (
          <ResponsiveContainer width="100%" height={350}>
            <RadarChart cx="50%" cy="50%" outerRadius={110} data={activity.data}>
              <PolarGrid />
              <PolarAngleAxis dataKey="name" stroke="#64748b" />
              <PolarRadiusAxis />
              <Radar name={dataKey} dataKey={dataKey} stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}
              />
              <Legend />
            </RadarChart>
          </ResponsiveContainer>
        );

      case 'bar':
      default:
        return (
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={activity.data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" stroke="#64748b" height={60} />
              <YAxis stroke="#64748b" />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0' }}
              />
              <Legend />
              <Bar dataKey={dataKey} fill="#e11d48" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <div className="flex items-center gap-2">
          <div className="flex items-center bg-white border border-slate-200 rounded-xl p-1 shadow-sm gap-1">
            {[
              { id: 'bar', label: '📊' },
              { id: 'line', label: '📈' },
              { id: 'pie', label: '🍕' },
              { id: 'radar', label: '🕸️' },
            ].map((fmt) => (
              <button
                key={fmt.id}
                onClick={() => setSelectedType(fmt.id as 'bar' | 'line' | 'pie' | 'radar')}
                className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedType === fmt.id ? 'bg-rose-100 text-rose-700 font-extrabold' : 'hover:bg-slate-100'
                }`}
              >
                {fmt.label}
              </button>
            ))}
          </div>

          <span className="text-xs font-extrabold text-rose-700 bg-rose-50 px-3 py-1 rounded-full border border-rose-200 flex items-center gap-1.5">
            <BarChart2 className="w-4 h-4 text-rose-500" />
            <span>{activity.subject}</span>
          </span>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{activity.title}</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">{activity.description}</p>
        </div>

        <div className="bg-slate-50/80 border border-slate-200 rounded-2xl p-6 shadow-inner">
          {renderChart()}
        </div>

        <div className="space-y-3 pt-2">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <Table className="w-4 h-4 text-rose-500" /> Tabela de Dados Brutos
          </h3>

          <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-slate-100 font-extrabold text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="p-3">Categoria / Item</th>
                  <th className="p-3 text-right">Valor ({dataKey})</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white">
                {activity.data.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50">
                    <td className="p-3 font-semibold text-slate-700">{row.name}</td>
                    <td className="p-3 text-right font-extrabold text-rose-600">
                      {row[dataKey] !== undefined ? String(row[dataKey]) : String(row.valor || 0)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
