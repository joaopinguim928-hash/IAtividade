'use client';

import React, { useState } from 'react';
import { DissertativeActivity } from '@/types';
import { useActivities } from '@/context/ActivityContext';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  FileText,
  Sparkles,
  Send,
  CheckCircle2,
  AlertCircle,
  Award,
  Loader2,
  BookOpen,
} from 'lucide-react';

interface DissertativePlayerProps {
  activity: DissertativeActivity;
}

export function DissertativePlayer({ activity }: DissertativePlayerProps) {
  const { setActiveView } = useActivities();

  const [studentAnswer, setStudentAnswer] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluation, setEvaluation] = useState<{
    score: number;
    feedback: string;
    strengths: string[];
    improvements: string[];
  } | null>(null);

  const question = activity.questions[0];

  const handleEvaluate = () => {
    if (!studentAnswer.trim() || isEvaluating) return;

    setIsEvaluating(true);

    setTimeout(() => {
      const length = studentAnswer.trim().length;
      let score = 9.0;
      if (length < 30) score = 4.5;
      else if (length < 80) score = 7.0;
      else if (length > 150) score = 10.0;

      setEvaluation({
        score,
        feedback:
          score >= 8.0
            ? 'Excelente articulação de ideias! Você apresentou argumentos bem estruturados com bom vocabulário técnico.'
            : 'Sua resposta aborda os pontos principais, mas pode ser aprofundada com mais exemplos e vocabulário específico.',
        strengths: [
          'Clareza na exposição do argumento central',
          'Coerência gramatical e boa estrutura frasal',
        ],
        improvements: [
          'Desenvolver mais detalhes sobre causa e consequência',
          'Incorporar termos técnicos relativos ao tema',
        ],
      });

      setIsEvaluating(false);
      if (score >= 7.0) {
        confetti({ particleCount: 70, spread: 80, origin: { y: 0.7 } });
      }
    }, 1500);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200 flex items-center gap-1.5">
          <FileText className="w-4 h-4 text-emerald-500" />
          <span>{activity.subject}</span>
        </span>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">{activity.title}</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">{activity.description}</p>
        </div>

        {question && (
          <div className="bg-emerald-50/50 p-6 rounded-2xl border border-emerald-200/80 space-y-2">
            <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider bg-emerald-100 px-2 py-0.5 rounded">
              Proposta / Pergunta
            </span>
            <p className="text-sm sm:text-base font-semibold text-slate-800 leading-relaxed">
              {question.prompt}
            </p>
          </div>
        )}

        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
            <span>Sua Resposta Dissertativa</span>
            <span className="text-slate-400 font-normal">
              {studentAnswer.trim().split(/\s+/).filter(Boolean).length} palavras
            </span>
          </label>

          <textarea
            value={studentAnswer}
            onChange={(e) => setStudentAnswer(e.target.value)}
            disabled={isEvaluating}
            placeholder="Digite aqui sua resposta com argumentação detalhada..."
            rows={6}
            className="w-full p-4 border border-slate-300 rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 resize-none leading-relaxed"
          />
        </div>

        <div className="flex justify-end">
          <button
            onClick={handleEvaluate}
            disabled={!studentAnswer.trim() || isEvaluating}
            className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-700 hover:to-indigo-700 text-white rounded-2xl font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2 disabled:opacity-50"
          >
            {isEvaluating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>Avaliando Resposta com IA...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>Submeter para Correção IA</span>
                <Send className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

        {evaluation && (
          <div className="mt-6 p-6 bg-slate-50 border border-slate-200 rounded-3xl space-y-5 animate-in fade-in duration-300">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center font-black text-xl shadow-inner">
                  {evaluation.score.toFixed(1)}
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">Avaliação do Corretor IA</h3>
                  <p className="text-xs text-slate-500">Nota: {evaluation.score} de {question?.maxPoints || 10} pontos</p>
                </div>
              </div>
              <Award className="w-8 h-8 text-amber-500" />
            </div>

            <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed bg-white p-4 rounded-xl border border-slate-200">
              {evaluation.feedback}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-emerald-50/80 p-4 rounded-2xl border border-emerald-200/80 space-y-2">
                <p className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" /> PONTOS FORTES
                </p>
                <ul className="space-y-1">
                  {evaluation.strengths.map((s, idx) => (
                    <li key={idx} className="text-[11px] text-emerald-900 flex items-start gap-1.5">
                      <span>•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-amber-50/80 p-4 rounded-2xl border border-amber-200/80 space-y-2">
                <p className="text-xs font-bold text-amber-800 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-600" /> SUGESTÕES DE MELHORIA
                </p>
                <ul className="space-y-1">
                  {evaluation.improvements.map((s, idx) => (
                    <li key={idx} className="text-[11px] text-amber-900 flex items-start gap-1.5">
                      <span>•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {question?.sampleAnswer && (
              <div className="pt-2">
                <p className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-indigo-600" /> Resposta Modelo / Gabarito de Referência:
                </p>
                <p className="text-xs text-slate-600 italic bg-white p-3.5 rounded-xl border border-slate-200">
                  &quot;{question.sampleAnswer}&quot;
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
