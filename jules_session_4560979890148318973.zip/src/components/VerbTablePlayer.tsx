'use client';

import React, { useState } from 'react';
import { VerbTableActivity } from '@/types';
import { useActivities } from '@/context/ActivityContext';
import confetti from 'canvas-confetti';
import {
  ArrowLeft,
  Table,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Sparkles,
  HelpCircle,
  Award,
} from 'lucide-react';

interface VerbTablePlayerProps {
  activity: VerbTableActivity;
}

export function VerbTablePlayer({ activity }: VerbTablePlayerProps) {
  const { setActiveView } = useActivities();

  const [inputs, setInputs] = useState<Record<number, string>>({});
  const [hasChecked, setHasChecked] = useState(false);
  const [showHints, setShowHints] = useState<Record<number, boolean>>({});

  const handleInputChange = (idx: number, val: string) => {
    if (hasChecked) return;
    setInputs({ ...inputs, [idx]: val });
  };

  const toggleHint = (idx: number) => {
    setShowHints({ ...showHints, [idx]: !showHints[idx] });
  };

  const correctAnswersCount = activity.conjugations.filter((row, idx) => {
    const userVal = (inputs[idx] || '').trim().toLowerCase();
    return userVal === row.answer.trim().toLowerCase();
  }).length;

  const total = activity.conjugations.length;
  const isPerfect = correctAnswersCount === total;

  const handleCheck = () => {
    setHasChecked(true);
    if (isPerfect) {
      confetti({ particleCount: 90, spread: 90, origin: { y: 0.7 } });
    }
  };

  const handleReset = () => {
    setInputs({});
    setHasChecked(false);
    setShowHints({});
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3.5 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <span className="text-xs font-extrabold text-sky-700 bg-sky-50 px-3 py-1 rounded-full border border-sky-200 flex items-center gap-1.5">
          <Table className="w-4 h-4 text-sky-500" />
          <span>{activity.subject}</span>
        </span>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-8 space-y-6">
        <div>
          <div className="inline-block px-3 py-1 bg-sky-100 text-sky-800 font-extrabold text-xs rounded-full uppercase tracking-wider mb-2">
            {activity.tense}
          </div>
          <h1 className="text-2xl font-bold text-slate-800">
            Conjugação do Verbo &quot;{activity.verb}&quot;
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">{activity.description}</p>
        </div>

        <div className="bg-slate-50 rounded-2xl p-4 sm:p-6 border border-slate-200/80 space-y-3">
          <div className="grid grid-cols-12 gap-2 text-[11px] font-extrabold text-slate-400 uppercase tracking-wider px-2">
            <span className="col-span-4">Pronome</span>
            <span className="col-span-6">Sua Resposta</span>
            <span className="col-span-2 text-center">Dica</span>
          </div>

          <div className="space-y-2.5">
            {activity.conjugations.map((row, idx) => {
              const userVal = (inputs[idx] || '').trim().toLowerCase();
              const isCorrect = userVal === row.answer.trim().toLowerCase();

              let inputBorder = 'border-slate-300 focus:border-sky-500 focus:ring-sky-500';
              if (hasChecked) {
                if (isCorrect) inputBorder = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold';
                else inputBorder = 'border-red-500 bg-red-50 text-red-900 font-bold';
              }

              return (
                <div key={idx} className="space-y-1">
                  <div className="grid grid-cols-12 gap-2 items-center">
                    <span className="col-span-4 text-xs sm:text-sm font-bold text-slate-700 bg-white px-3 py-2.5 rounded-xl border border-slate-200">
                      {row.pronoun}
                    </span>

                    <div className="col-span-6 relative">
                      <input
                        type="text"
                        disabled={hasChecked}
                        value={inputs[idx] || ''}
                        onChange={(e) => handleInputChange(idx, e.target.value)}
                        placeholder="Digite o verbo..."
                        className={`w-full px-3.5 py-2.5 rounded-xl border text-xs sm:text-sm focus:outline-none focus:ring-2 transition-all ${inputBorder}`}
                      />
                      {hasChecked && (
                        <div className="absolute right-3 top-1/2 -translate-y-1/2">
                          {isCorrect ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-600" />
                          )}
                        </div>
                      )}
                    </div>

                    <div className="col-span-2 flex justify-center">
                      <button
                        type="button"
                        onClick={() => toggleHint(idx)}
                        className="p-2 text-slate-400 hover:text-sky-600 hover:bg-sky-50 rounded-xl transition-colors"
                        title="Ver Dica"
                      >
                        <HelpCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {showHints[idx] && (
                    <div className="ml-4 p-2.5 bg-sky-50 border border-sky-200 rounded-xl text-[11px] text-sky-800 animate-in fade-in">
                      💡 Dica: Começa com &quot;<span className="font-bold">{row.answer.slice(0, 3)}</span>...&quot;
                    </div>
                  )}

                  {hasChecked && !isCorrect && (
                    <div className="ml-4 text-[11px] font-semibold text-slate-500">
                      Resposta correta: <span className="text-emerald-700 font-bold">{row.answer}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {!hasChecked ? (
          <div className="flex justify-end">
            <button
              onClick={handleCheck}
              className="px-6 py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-2xl font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Verificar Respostas</span>
            </button>
          </div>
        ) : (
          <div className="p-6 bg-slate-50 rounded-3xl border border-slate-200 text-center space-y-4">
            <div className="inline-flex p-3 bg-sky-100 text-sky-600 rounded-2xl">
              <Award className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-800">
                {isPerfect ? 'Parabéns! Desempenho Perfeito 🎉' : 'Resultado do Treino'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Você acertou <span className="font-extrabold text-sky-600">{correctAnswersCount}</span> de{' '}
                <span className="font-bold">{total}</span> formas verbais.
              </p>
            </div>

            <div className="flex justify-center gap-3 pt-2">
              <button
                onClick={handleReset}
                className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Tentar Novamente</span>
              </button>

              <button
                onClick={() => setActiveView('dashboard')}
                className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl font-bold text-xs transition-colors shadow-md"
              >
                Voltar ao Painel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
