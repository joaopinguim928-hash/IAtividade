'use client';

import React, { useState } from 'react';
import { useActivities } from '@/context/ActivityContext';
import { VerbTableActivity, VerbConjugationRow } from '@/types';
import { ArrowLeft, Save, Table, Plus, Trash2 } from 'lucide-react';

export function VerbTableEditor() {
  const { addActivity, setActiveView, setSelectedActivity } = useActivities();

  const [verb, setVerb] = useState('');
  const [tense, setTense] = useState('Presente do Indicativo');
  const [subject] = useState('Língua Portuguesa');
  const [title, setTitle] = useState('');
  const [description] = useState('');

  const [conjugations, setConjugations] = useState<VerbConjugationRow[]>([
    { pronoun: 'Eu', answer: '' },
    { pronoun: 'Tu', answer: '' },
    { pronoun: 'Ele/Ela', answer: '' },
    { pronoun: 'Nós', answer: '' },
    { pronoun: 'Vós', answer: '' },
    { pronoun: 'Eles/Elas', answer: '' },
  ]);

  const handleRowChange = (index: number, field: keyof VerbConjugationRow, value: string) => {
    const updated = [...conjugations];
    updated[index] = { ...updated[index], [field]: value };
    setConjugations(updated);
  };

  const handleAddRow = () => {
    setConjugations([...conjugations, { pronoun: 'Outro', answer: '' }]);
  };

  const handleRemoveRow = (index: number) => {
    if (conjugations.length <= 1) return;
    setConjugations(conjugations.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!verb.trim() || conjugations.some((c) => !c.answer.trim())) return;

    const newActivity: VerbTableActivity = {
      id: 'act_verb_' + Date.now(),
      type: 'verb_table',
      title: title || `Conjugação: Verbo "${verb}" (${tense})`,
      description: description || `Pratique a conjugação do verbo ${verb} no tempo ${tense}.`,
      verb,
      tense,
      subject,
      createdAt: new Date().toISOString(),
      conjugations,
      authorId: 'usr_demo',
    };

    addActivity(newActivity);
    setSelectedActivity(newActivity);
    setActiveView('play_activity');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setActiveView('dashboard')}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Voltar ao Painel</span>
        </button>

        <span className="text-xs font-bold text-sky-700 bg-sky-50 px-3 py-1 rounded-full border border-sky-200 flex items-center gap-1.5">
          <Table className="w-4 h-4 text-sky-500" />
          <span>Nova Tabela de Verbos</span>
        </span>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h2 className="text-lg font-bold text-slate-800">Parâmetros do Verbo</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Verbo no Infinitivo</label>
              <input
                type="text"
                required
                value={verb}
                onChange={(e) => setVerb(e.target.value)}
                placeholder="Ex: cantar, estudar, vender..."
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Tempo e Modo Verbal</label>
              <input
                type="text"
                required
                value={tense}
                onChange={(e) => setTense(e.target.value)}
                placeholder="Ex: Pretérito Perfeito do Indicativo"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1">Título Personalizado (Opcional)</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Exercício de Verbos Regulares em -AR"
                className="w-full px-3.5 py-2.5 border border-slate-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-800">Conjugação Correta (Gabarito)</h3>
            <button
              type="button"
              onClick={handleAddRow}
              className="px-3 py-1.5 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Linha
            </button>
          </div>

          <div className="space-y-3">
            {conjugations.map((row, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <input
                  type="text"
                  required
                  value={row.pronoun}
                  onChange={(e) => handleRowChange(idx, 'pronoun', e.target.value)}
                  placeholder="Pronome (ex: Eu)"
                  className="w-28 sm:w-36 px-3 py-2 border border-slate-300 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />

                <input
                  type="text"
                  required
                  value={row.answer}
                  onChange={(e) => handleRowChange(idx, 'answer', e.target.value)}
                  placeholder="Forma conjugada (ex: cantei)"
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />

                {conjugations.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleRemoveRow(idx)}
                    className="p-2 text-slate-400 hover:text-red-600 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="submit"
            className="px-6 py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-2xl font-bold text-sm shadow-md transition-all flex items-center gap-2"
          >
            <Save className="w-4 h-4" />
            <span>Salvar Tabela e Iniciar Jogo</span>
          </button>
        </div>
      </form>
    </div>
  );
}
