'use client';

import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { Sparkles, LogIn } from 'lucide-react';

interface NavbarProps {
  onOpenAiModal: () => void;
}

export function Navbar({ onOpenAiModal }: NavbarProps) {
  const { user, openAuthModal } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/80 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-3 cursor-pointer">
          <div className="bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 text-white p-2.5 rounded-xl shadow-md shadow-indigo-200">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                IAtividade
              </span>
              <span className="bg-indigo-100 text-indigo-700 text-[10px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wider">
                IA 2.0
              </span>
            </div>
            <p className="text-[10px] text-slate-400 font-medium">
              Atividades Interativas, Gráficos & Mapas Mentais
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAiModal}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl text-sm font-semibold shadow-md shadow-indigo-100 transition-all transform hover:-translate-y-0.5"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Criar com IA</span>
          </button>

          <div className="h-6 w-[1px] bg-slate-200 mx-1 hidden sm:block" />

          {user ? (
            <button
              onClick={() => openAuthModal('login')}
              className="flex items-center gap-2.5 p-1.5 pr-3 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200/80"
            >
              <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-sm shadow-inner">
                {user.name.charAt(0)}
              </div>
              <div className="text-left hidden sm:block">
                <p className="text-xs font-semibold text-slate-800 leading-none">{user.name}</p>
                <p className="text-[10px] text-slate-400 mt-0.5 capitalize">
                  {user.role === 'teacher' ? 'Professor' : 'Estudante'}
                </p>
              </div>
            </button>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="flex items-center gap-2 px-3.5 py-2 text-slate-700 hover:text-indigo-600 hover:bg-indigo-50/80 rounded-xl text-sm font-semibold transition-colors border border-slate-200"
            >
              <LogIn className="w-4 h-4" />
              <span>Entrar</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
