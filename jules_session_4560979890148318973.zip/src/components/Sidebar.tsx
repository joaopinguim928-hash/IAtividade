'use client';

import React from 'react';
import { useActivities } from '@/context/ActivityContext';
import {
  LayoutDashboard,
  HelpCircle,
  FileText,
  Table,
  GitFork,
  BarChart2,
  Plus,
  Sparkles,
  Search,
  Filter,
} from 'lucide-react';

interface SidebarProps {
  onOpenAiModal: () => void;
}

export function Sidebar({ onOpenAiModal }: SidebarProps) {
  const {
    activeView,
    setActiveView,
    setSelectedActivity,
    selectedFilter,
    setSelectedFilter,
    searchQuery,
    setSearchQuery,
  } = useActivities();

  const handleGoDashboard = () => {
    setSelectedActivity(null);
    setActiveView('dashboard');
  };

  const handleCreateType = (
    typeView:
      | 'create_quiz'
      | 'create_dissertative'
      | 'create_verb'
      | 'create_mindmap'
      | 'create_chart'
  ) => {
    setSelectedActivity(null);
    setActiveView(typeView);
  };

  const filterOptions = [
    { id: 'all', label: 'Todos os Recursos', icon: LayoutDashboard },
    { id: 'quiz', label: 'Quizzes / Múltipla Escolha', icon: HelpCircle },
    { id: 'dissertative', label: 'Questões Dissertativas', icon: FileText },
    { id: 'verb_table', label: 'Tabelas de Verbos', icon: Table },
    { id: 'mindmap', label: 'Mapas Mentais', icon: GitFork },
    { id: 'chart', label: 'Gráficos Interativos', icon: BarChart2 },
  ];

  return (
    <aside className="w-full lg:w-72 bg-white border-r border-slate-200/80 p-4 flex flex-col space-y-6 shrink-0">
      <button
        onClick={onOpenAiModal}
        className="w-full py-3 px-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-bold shadow-lg shadow-indigo-100 flex items-center justify-center gap-2 transition-all transform hover:scale-[1.02]"
      >
        <Sparkles className="w-5 h-5 text-amber-300 animate-spin-slow" />
        <span>Gerar com IA</span>
      </button>

      <div className="relative">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Buscar atividade ou tema..."
          className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
        />
      </div>

      <div>
        <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2">
          Navegação
        </p>
        <button
          onClick={handleGoDashboard}
          className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
            activeView === 'dashboard'
              ? 'bg-indigo-50 text-indigo-700 shadow-sm'
              : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
          }`}
        >
          <LayoutDashboard className="w-4 h-4 text-indigo-600" />
          <span>Painel Principal</span>
        </button>
      </div>

      <div>
        <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2 flex items-center justify-between">
          <span>Criar Manualmente</span>
          <Plus className="w-3.5 h-3.5" />
        </p>
        <div className="space-y-1">
          <button
            onClick={() => handleCreateType('create_quiz')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
              activeView === 'create_quiz'
                ? 'bg-amber-50 text-amber-700 font-semibold'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-amber-500" />
            <span>Quiz Múltipla Escolha</span>
          </button>

          <button
            onClick={() => handleCreateType('create_dissertative')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
              activeView === 'create_dissertative'
                ? 'bg-emerald-50 text-emerald-700 font-semibold'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-500" />
            <span>Questão Dissertativa</span>
          </button>

          <button
            onClick={() => handleCreateType('create_verb')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
              activeView === 'create_verb'
                ? 'bg-sky-50 text-sky-700 font-semibold'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Table className="w-4 h-4 text-sky-500" />
            <span>Tabela de Verbos</span>
          </button>

          <button
            onClick={() => handleCreateType('create_mindmap')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
              activeView === 'create_mindmap'
                ? 'bg-purple-50 text-purple-700 font-semibold'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <GitFork className="w-4 h-4 text-purple-500" />
            <span>Mapa Mental</span>
          </button>

          <button
            onClick={() => handleCreateType('create_chart')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
              activeView === 'create_chart'
                ? 'bg-rose-50 text-rose-700 font-semibold'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            <BarChart2 className="w-4 h-4 text-rose-500" />
            <span>Gráfico Interativo</span>
          </button>
        </div>
      </div>

      <div className="pt-2 border-t border-slate-100">
        <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-2 flex items-center gap-1.5">
          <Filter className="w-3 h-3" />
          <span>Filtrar por Categoria</span>
        </p>
        <div className="space-y-1">
          {filterOptions.map((opt) => {
            const Icon = opt.icon;
            const isSelected = selectedFilter === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => {
                  setSelectedFilter(opt.id);
                  if (activeView !== 'dashboard') {
                    setSelectedActivity(null);
                    setActiveView('dashboard');
                  }
                }}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                  isSelected
                    ? 'bg-slate-100 text-slate-900 font-semibold border-l-2 border-indigo-600'
                    : 'text-slate-500 hover:bg-slate-50 hover:text-slate-800'
                }`}
              >
                <Icon className="w-4 h-4 text-slate-400" />
                <span>{opt.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </aside>
  );
}
