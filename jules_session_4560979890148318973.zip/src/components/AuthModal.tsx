'use client';

import React, { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { X, LogIn, UserPlus, Sparkles, CheckCircle2 } from 'lucide-react';

export function AuthModal() {
  const { isAuthModalOpen, closeAuthModal, authMode, setAuthMode, login, register, user, logout } = useAuth();
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'teacher' | 'student'>('teacher');

  if (!isAuthModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (authMode === 'login') {
      if (!email) return;
      login(email, name || undefined);
    } else {
      if (!email || !name) return;
      register(name, email, role);
    }
  };

  const handleQuickDemoLogin = (demoRole: 'teacher' | 'student') => {
    if (demoRole === 'teacher') {
      login('prof.silva@escola.edu.br', 'Prof. Ana Silva');
    } else {
      login('aluno.lucas@escola.edu.br', 'Lucas Mendes');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-100">
        <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-6 text-white relative">
          <button
            onClick={closeAuthModal}
            className="absolute top-4 right-4 text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2 mb-2">
            <div className="p-2 bg-white/10 rounded-lg backdrop-blur-md">
              <Sparkles className="w-6 h-6 text-amber-300" />
            </div>
            <span className="font-bold text-xl tracking-tight">IAtividade</span>
          </div>
          <h2 className="text-2xl font-bold">
            {user ? 'Sua Conta' : authMode === 'login' ? 'Entrar na Plataforma' : 'Criar Conta Grátis'}
          </h2>
          <p className="text-xs text-indigo-100 mt-1">
            Plataforma Inteligente de Atividades Interativas e Mapas Mentais
          </p>
        </div>

        <div className="p-6">
          {user ? (
            <div className="text-center py-4">
              <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 text-2xl font-bold mx-auto mb-3">
                {user.name.charAt(0)}
              </div>
              <h3 className="text-lg font-semibold text-slate-800">{user.name}</h3>
              <p className="text-sm text-slate-500 mb-6">{user.email}</p>
              <div className="flex items-center justify-center gap-2 mb-6 text-xs text-indigo-700 bg-indigo-50 py-2 px-3 rounded-lg font-medium">
                <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                <span>Perfil: {user.role === 'teacher' ? 'Educador / Professor' : 'Estudante'}</span>
              </div>
              <button
                onClick={() => {
                  logout();
                  closeAuthModal();
                }}
                className="w-full py-2.5 px-4 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl font-medium transition-colors"
              >
                Sair da Conta
              </button>
            </div>
          ) : (
            <>
              <div className="mb-6 bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
                <p className="text-xs font-semibold text-slate-600 mb-2.5 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  Acesso Rápido de Demonstração
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleQuickDemoLogin('teacher')}
                    className="py-2 px-3 text-xs bg-white hover:bg-indigo-50 border border-slate-200 text-slate-700 hover:text-indigo-600 rounded-lg font-medium transition-all shadow-sm text-left flex items-center gap-2"
                  >
                    <span>🎓</span>
                    <div>
                      <div className="font-semibold">Como Professor</div>
                      <div className="text-[10px] text-slate-400">Criar e gerenciar</div>
                    </div>
                  </button>
                  <button
                    onClick={() => handleQuickDemoLogin('student')}
                    className="py-2 px-3 text-xs bg-white hover:bg-purple-50 border border-slate-200 text-slate-700 hover:text-purple-600 rounded-lg font-medium transition-all shadow-sm text-left flex items-center gap-2"
                  >
                    <span>🎒</span>
                    <div>
                      <div className="font-semibold">Como Aluno</div>
                      <div className="text-[10px] text-slate-400">Responder e praticar</div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-slate-400 font-medium">ou informe seus dados</span>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {authMode === 'register' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Nome Completo
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Ex: Maria Santos"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    E-mail
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="seu.email@exemplo.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                  />
                </div>

                {authMode === 'register' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Perfil
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setRole('teacher')}
                        className={`py-2 px-3 text-xs rounded-xl font-medium border text-center transition-all ${
                          role === 'teacher'
                            ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-semibold'
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}
                      >
                        Educador / Prof.
                      </button>
                      <button
                        type="button"
                        onClick={() => setRole('student')}
                        className={`py-2 px-3 text-xs rounded-xl font-medium border text-center transition-all ${
                          role === 'student'
                            ? 'bg-purple-50 border-purple-500 text-purple-700 font-semibold'
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}
                      >
                        Estudante
                      </button>
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full mt-2 py-3 px-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-2"
                >
                  {authMode === 'login' ? (
                    <>
                      <LogIn className="w-4 h-4" /> Entrar
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4" /> Criar Minha Conta
                    </>
                  )}
                </button>
              </form>

              <div className="mt-4 text-center">
                <button
                  onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
                  className="text-xs text-indigo-600 hover:text-indigo-800 font-medium"
                >
                  {authMode === 'login'
                    ? 'Não tem conta? Clique para cadastrar-se'
                    : 'Já tem conta? Clique para entrar'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
