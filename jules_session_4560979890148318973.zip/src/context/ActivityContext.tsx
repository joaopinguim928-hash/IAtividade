'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { AnyActivity } from '@/types';
import { INITIAL_ACTIVITIES } from '@/data/mockData';

interface ActivityContextType {
  activities: AnyActivity[];
  addActivity: (activity: AnyActivity) => void;
  updateActivity: (activity: AnyActivity) => void;
  deleteActivity: (id: string) => void;
  selectedActivity: AnyActivity | null;
  setSelectedActivity: (activity: AnyActivity | null) => void;
  activeView: 'dashboard' | 'create_quiz' | 'create_dissertative' | 'create_verb' | 'create_mindmap' | 'create_chart' | 'play_activity';
  setActiveView: (view: 'dashboard' | 'create_quiz' | 'create_dissertative' | 'create_verb' | 'create_mindmap' | 'create_chart' | 'play_activity') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedFilter: string;
  setSelectedFilter: (filter: string) => void;
}

const ActivityContext = createContext<ActivityContextType | undefined>(undefined);

export function ActivityProvider({ children }: { children: React.ReactNode }) {
  const [activities, setActivities] = useState<AnyActivity[]>([]);
  const [selectedActivity, setSelectedActivity] = useState<AnyActivity | null>(null);
  const [activeView, setActiveView] = useState<'dashboard' | 'create_quiz' | 'create_dissertative' | 'create_verb' | 'create_mindmap' | 'create_chart' | 'play_activity'>('dashboard');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  useEffect(() => {
    const stored = localStorage.getItem('iatividade_items');
    if (stored) {
      try {
        setActivities(JSON.parse(stored));
      } catch {
        setActivities(INITIAL_ACTIVITIES);
        localStorage.setItem('iatividade_items', JSON.stringify(INITIAL_ACTIVITIES));
      }
    } else {
      setActivities(INITIAL_ACTIVITIES);
      localStorage.setItem('iatividade_items', JSON.stringify(INITIAL_ACTIVITIES));
    }
  }, []);

  const saveToStorage = (items: AnyActivity[]) => {
    setActivities(items);
    localStorage.setItem('iatividade_items', JSON.stringify(items));
  };

  const addActivity = (activity: AnyActivity) => {
    const updated = [activity, ...activities];
    saveToStorage(updated);
  };

  const updateActivity = (activity: AnyActivity) => {
    const updated = activities.map((a) => (a.id === activity.id ? activity : a));
    saveToStorage(updated);
  };

  const deleteActivity = (id: string) => {
    const updated = activities.filter((a) => a.id !== id);
    saveToStorage(updated);
    if (selectedActivity?.id === id) {
      setSelectedActivity(null);
      setActiveView('dashboard');
    }
  };

  return (
    <ActivityContext.Provider
      value={{
        activities,
        addActivity,
        updateActivity,
        deleteActivity,
        selectedActivity,
        setSelectedActivity,
        activeView,
        setActiveView,
        searchQuery,
        setSearchQuery,
        selectedFilter,
        setSelectedFilter,
      }}
    >
      {children}
    </ActivityContext.Provider>
  );
}

export function useActivities() {
  const context = useContext(ActivityContext);
  if (!context) {
    throw new Error('useActivities must be used within an ActivityProvider');
  }
  return context;
}
