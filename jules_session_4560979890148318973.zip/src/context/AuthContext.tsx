'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '@/types';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, name?: string) => void;
  register: (name: string, email: string, role?: 'teacher' | 'student') => void;
  logout: () => void;
  isAuthModalOpen: boolean;
  openAuthModal: (mode?: 'login' | 'register') => void;
  closeAuthModal: () => void;
  authMode: 'login' | 'register';
  setAuthMode: (mode: 'login' | 'register') => void;
}

const DEFAULT_USER: User = {
  id: 'usr_demo',
  name: 'Professor Silva',
  email: 'prof.silva@escola.edu.br',
  role: 'teacher',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  useEffect(() => {
    const stored = localStorage.getItem('iatividade_user');
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {
        setUser(DEFAULT_USER);
        localStorage.setItem('iatividade_user', JSON.stringify(DEFAULT_USER));
      }
    } else {
      setUser(DEFAULT_USER);
      localStorage.setItem('iatividade_user', JSON.stringify(DEFAULT_USER));
    }
    setIsLoading(false);
  }, []);

  const login = (email: string, name?: string) => {
    const newUser: User = {
      id: 'usr_' + Date.now(),
      name: name || (email.split('@')[0] || 'Usuário'),
      email: email,
      role: 'teacher',
    };
    setUser(newUser);
    localStorage.setItem('iatividade_user', JSON.stringify(newUser));
    setIsAuthModalOpen(false);
  };

  const register = (name: string, email: string, role: 'teacher' | 'student' = 'teacher') => {
    const newUser: User = {
      id: 'usr_' + Date.now(),
      name,
      email,
      role,
    };
    setUser(newUser);
    localStorage.setItem('iatividade_user', JSON.stringify(newUser));
    setIsAuthModalOpen(false);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('iatividade_user');
  };

  const openAuthModal = (mode: 'login' | 'register' = 'login') => {
    setAuthMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        login,
        register,
        logout,
        isAuthModalOpen,
        openAuthModal,
        closeAuthModal,
        authMode,
        setAuthMode,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
